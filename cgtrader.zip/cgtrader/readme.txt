Enter email and password in "login.txt"
	email
	pass
	email
	pass


Select category from categories.txt
and paste category inside input.txt


path: /Desktop/cgtrader/cgtrader/spiders/cgtrader.py
	
	open "cgtrader.py" using upper path
	Now add "email" and "password"


Then run this on terminal: scrapy crawl cgtrader -o data.json -t json
